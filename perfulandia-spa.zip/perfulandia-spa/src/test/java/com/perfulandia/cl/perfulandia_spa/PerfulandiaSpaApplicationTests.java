package com.perfulandia.cl.perfulandia_spa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfulandiaSpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
